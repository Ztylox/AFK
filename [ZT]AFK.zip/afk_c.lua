
function onClientChatInput(state)
    triggerServerEvent("onPlayerChatInput", localPlayer, state)
end

addEventHandler("onClientKey", root, function(button, press)
    if button == "t" or button == "y" then
        if press then
            onClientChatInput(true)
        end
    end
end)

addEventHandler("onClientCharacter", root, function()
    if guiGetInputMode() == "allow_binds" then
        onClientChatInput(false)
    end
end)
