-- server.lua

-- Tiempo en segundos para activar el modo AFK automáticamente
local AFK_TIME = 60

-- Tablas para almacenar el último tiempo de actividad de cada jugador y el estado del chat
local lastActivity = {}
local isChatBoxActive = {}

-- Función para verificar la actividad del jugador
function checkAFK()
    for _, player in ipairs(getElementsByType("player")) do
        if not isPlayerActive(player) and not getElementData(player, "manualAFK") then
            if not lastActivity[player] then
                lastActivity[player] = getTickCount()
            elseif getTickCount() - lastActivity[player] > AFK_TIME * 1000 then
                if not isPlayerAFK(player) then
                    setPlayerAFK(player, true)
                end
            end
        else
            lastActivity[player] = getTickCount()
            if isPlayerAFK(player) then
                setPlayerAFK(player, false)
                setElementData(player, "manualAFK", false) -- Resetear el estado manualAFK
            end
        end
    end
end
setTimer(checkAFK, 1000, 0)


function isPlayerActive(player)
    return getControlState(player, "forwards") or getControlState(player, "backwards") or
           getControlState(player, "left") or getControlState(player, "right") or
           getControlState(player, "fire") or getControlState(player, "aim_weapon") or
           (isChatBoxActive[player] == true)
end


function isPlayerAFK(player)
    return getElementData(player, "isAFK")
end

-- Función para establecer el estado AFK del jugador
function setPlayerAFK(player, state)
    if getElementData(player, "isAFK") ~= state then
        setElementData(player, "isAFK", state)
        if state then
            toggleControl(player, "fire", false)
            toggleControl(player, "aim_weapon", false)
            setElementAlpha(player, 150)  -- Hacer al jugador transparente
            outputChatBox(getPlayerName(player) .. " está ahora AFK.", root, 255, 255, 0)
        else
            toggleControl(player, "fire", true)
            toggleControl(player, "aim_weapon", true)
            setElementAlpha(player, 255)  -- Restaurar opacidad del jugador
            outputChatBox(getPlayerName(player) .. " ha vuelto de AFK.", root, 0, 255, 0)
        end
    end
end


function preventAFKDamage(attacker, weapon, bodypart, loss)
    if isPlayerAFK(source) then
        cancelEvent()
    end
end
addEventHandler("onPlayerDamage", root, preventAFKDamage)

-- Comando para activar/desactivar manualmente el modo AFK (NOTA)REVISAR,EN LA LINEA DEL COMANDHANDLER SE ESPECIFICA
function toggleManualAFK(player)
    if getElementData(player, "manualAFK") then
        setElementData(player, "manualAFK", false)
        setPlayerAFK(player, false)
        outputChatBox(getPlayerName(player) .. " ha desactivado el modo AFK manual.", root, 0, 255, 0)
    else
        setElementData(player, "manualAFK", true)
        setPlayerAFK(player, true)
        outputChatBox(getPlayerName(player) .. " ha activado el modo AFK manual.", root, 255, 255, 0)
   end
end
--addCommandHandler("afk", toggleManualAFK) --Revisar al usar el comando el modo afk se desactiva pocos segundos despues

function resetManualAFK(player)
    if getElementData(player, "manualAFK") then
        setElementData(player, "manualAFK", false)
        setPlayerAFK(player, false)
    end
end


addEventHandler("onPlayerControlStateChange", root, function(control, state)
    if state and (control == "forwards" or control == "backwards" or control == "left" or control == "right" or control == "fire" or control == "aim_weapon") then
        resetManualAFK(source)
    end
end)


addEventHandler("onPlayerChat", root, function(message, messageType)
    resetManualAFK(source)
end)


addEvent("onPlayerChatInput", true)
addEventHandler("onPlayerChatInput", root, function(state)
    isChatBoxActive[source] = state
    if not state then
        resetManualAFK(source)
    end
end)
